export default function App() {
  return (
    <div style={{ padding: '40px', fontFamily: 'sans-serif' }}>
      <h1>NovaAssist™</h1>
      <p>AI-powered virtual assistants to help your business grow, save time, and stay productive.</p>
      <a href="https://calendly.com/yourlink/va-consult" target="_blank" rel="noopener noreferrer">
        Book a Free 10-Min Call
      </a>
    </div>
  );
}
